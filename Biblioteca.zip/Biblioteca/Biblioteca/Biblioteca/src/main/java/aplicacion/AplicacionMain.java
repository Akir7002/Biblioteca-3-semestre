package aplicacion;

import javafx.application.Application;
import javafx.stage.Stage;
import modelo.Libro;
import repositorio.BibliotecaRepositorio;
import repositorio.IRepositorio;
import vista.WebLauncher;

public class AplicacionMain extends Application {

    @Override
    public void start(Stage primaryStage) {
        // Inicia el servidor web sin una ventana de JavaFX
        IRepositorio<Libro> repositorioLibros = new BibliotecaRepositorio();
        WebLauncher webLauncher = new WebLauncher(repositorioLibros);
        webLauncher.iniciar();
    }

    public static void main(String[] args) {
        launch(args);
    }
}