# 📚 Sistema de Gestión de Biblioteca

¡Bienvenido al Sistema de Gestión de Biblioteca! Una aplicación Java elegante y funcional para administrar recursos bibliográficos de manera eficiente.

## 🌟 Características

✨ **Gestión completa de libros**: Agregar, buscar, actualizar y eliminar libros
📖 **Información detallada**: Título, autor y cantidad disponible
🎯 **Arquitectura MVC**: Diseño limpio y mantenible
🔍 **Búsquedas flexibles**: Por título, autor o ambos
📊 **Reportes**: Visualización clara del inventario
⚡ **Interfaz de consola**: Fácil de usar y navegar

## 🏗️ Arquitectura del Proyecto

El proyecto sigue el patrón **Modelo-Vista-Controlador (MVC)** para una mejor organización y mantenibilidad:

```
src/main/java/
├── 📁 aplicacion/          # Punto de entrada de la aplicación
│   ├── AplicacionMain.java # Clase principal
│   └── Aplicacionweb.java  # Versión web (Swing)
├── 📁 controlador/         # Lógica de control
│   ├── BibliotecaControlador.java
│   └── IControlador.java
├── 📁 modelo/              # Entidades de datos
│   ├── Libro.java
│   └── RecursoBiblioteca.java
├── 📁 repositorio/         # Acceso a datos
│   ├── BibliotecaRepositorio.java
│   └── IRepositorio.java
└── 📁 vista/               # Interfaz de usuario
    ├── BibliotecaVista.java
    ├── BibliotecaSwingVista.java
    └── IVista.java
```

## 🚀 Instalación y Ejecución

### Prerrequisitos

- ☕ Java 23 o superior
- 📦 Maven 3.6+
- 🖥️ IDE recomendado: IntelliJ IDEA, Eclipse o VS Code

### Pasos para ejecutar

1. **Clonar el proyecto** (si aplica) o descargar los archivos

2. **Navegar al directorio del proyecto**:
   ```bash
   cd Biblioteca
   ```

3. **Compilar el proyecto**:
   ```bash
   mvn clean compile
   ```

4. **Ejecutar la aplicación**:
   ```bash
   mvn exec:java -Dexec.mainClass="aplicacion.AplicacionMain"
   ```

   O directamente:
   ```bash
   java -cp target/classes aplicacion.AplicacionMain
   ```

## 📋 Funcionalidades Disponibles

### 🔧 Gestión de Libros

| Opción | Descripción |
|--------|-------------|
| ➕ **Agregar libro** | Registra un nuevo libro con título, autor y cantidad |
| 📚 **Listar libros** | Muestra todos los libros disponibles en la biblioteca |
| 🔍 **Buscar libro** | Encuentra libros por título, autor o ambos criterios |
| ✏️ **Actualizar libro** | Modifica la información de un libro existente |
| 🗑️ **Eliminar libro** | Remueve un libro del sistema |
| 📊 **Generar reporte** | Estadísticas del inventario |

### 📖 Datos de Ejemplo

El sistema incluye algunos libros precargados:
- 📕 **"El Quijote"** - Miguel de Cervantes (3 copias)
- 📗 **"Cien años de soledad"** - Gabriel García Márquez (2 copias)  
- 📘 **"1984"** - George Orwell (5 copias)

## 💻 Ejemplo de Uso

```java
// Crear instancias del sistema
IRepositorio<Libro> repositorio = new BibliotecaRepositorio();
IVista vista = new BibliotecaVista();
IControlador controlador = new BibliotecaControlador(repositorio, vista);

// Agregar un libro
repositorio.crear(new Libro("El Principito", "Antoine de Saint-Exupéry", 4));

// Ejecutar la aplicación
controlador.ejecutar();
```

## 🎨 Interfaces de Usuario

### 🖥️ Versión Consola
- Interfaz de texto simple y clara
- Menús interactivos
- Navegación por opciones numéricas

### 🖼️ Versión Swing (GUI)
- Interfaz gráfica amigable
- Ventanas modales para operaciones
- Tablas para visualización de datos

## 🧪 Testing

Para ejecutar las pruebas (cuando estén disponibles):

```bash
mvn test
```

## 📝 Contribución

¿Quieres contribuir al proyecto? ¡Genial! Sigue estos pasos:

1. 🍴 Fork el proyecto
2. 🌿 Crea una rama para tu feature (`git checkout -b feature/AmazingFeature`)
3. 💾 Commit tus cambios (`git commit -m 'Add some AmazingFeature'`)
4. 📤 Push a la rama (`git push origin feature/AmazingFeature`)
5. 🔄 Abre un Pull Request

## 🛠️ Tecnologías Utilizadas

- **☕ Java 23**: Lenguaje de programación principal
- **📦 Maven**: Gestión de dependencias y construcción
- **🎨 Swing**: Interfaz gráfica (versión GUI)
- **🏗️ MVC Pattern**: Patrón de arquitectura

## 📊 Diagrama UML

El proyecto incluye un diagrama UML que muestra la estructura de clases. Puedes encontrarlo en:
- `biblioteca-uml-diagram.md`
- `Diagrama de biblioteca.mmd`

## 🤝 Autor

Desarrollado con ❤️ como parte del aprendizaje de Java y patrones de diseño.

## 📄 Licencia

Este proyecto es de código abierto y está disponible para fines educativos.

---

⭐ **¡Si te gusta este proyecto, dale una estrella!** ⭐

🐛 **¿Encontraste un bug?** Abre un issue y lo solucionaremos juntos.

💡 **¿Tienes ideas para mejorarlo?** ¡Todas las sugerencias son bienvenidas!

---

*Hecho con 💻 , mucho ☕ y IA (Insomnio y ansieda) en Java* // parece chiste pero es anecdota