# Diagrama UML del Sistema de Biblioteca

Este es el diagrama UML de clases para el sistema de gestión de biblioteca.

```mermaid
---
title: Sistema de Gestión de Biblioteca
---
classDiagram
    %% Interfaces
    class IControlador {
        <<interface>>
        +ejecutar()
        +agregarLibro()
        +listarLibros()
        +buscarLibro()
        +prestarLibro()
        +devolverLibro()
        +eliminarLibro()
    }
    
    class IRepositorio~T~ {
        <<interface>>
        +crear(T entidad) bool
        +obtenerPorId(int id) T
        +obtenerTodos() List~T~
        +actualizar(T entidad) bool
        +eliminar(int id) bool
    }
    
    class IVista {
        <<interface>>
        +mostrarMenu()
        +mostrarLibros(List~Libro~ libros)
        +mostrarMensaje(String mensaje)
        +leerOpcion() int
        +leerTexto(String prompt) String
        +leerNumero(String prompt) int
    }
    
    %% Modelo
    class RecursoBiblioteca {
        <<abstract>>
        -int id
        +getId() int
        +setId(int id)
    }
    
    class Libro {
        -String titulo
        -String autor
        -int cantidadDisponible
        +Libro()
        +Libro(String titulo, String autor, int cantidad)
        +getTitulo() String
        +setTitulo(String titulo)
        +getAutor() String
        +setAutor(String autor)
        +getCantidadDisponible() int
        +setCantidadDisponible(int cantidad)
        +prestar() bool
        +devolver()
        +toString() String
    }
    
    %% Repositorio
    class BibliotecaRepositorio {
        -List~Libro~ libros
        -int contadorId
        +BibliotecaRepositorio()
        -inicializarDatosPrueba()
        +crear(Libro libro) bool
        +obtenerPorId(int id) Libro
        +obtenerTodos() List~Libro~
        +actualizar(Libro libro) bool
        +eliminar(int id) bool
        +buscarPorTitulo(String titulo) List~Libro~
        +buscarPorAutor(String autor) List~Libro~
        +prestar(int id) bool
        +devolver(int id) bool
    }
    
    %% Vista
    class BibliotecaVista {
        -Scanner scanner
        +BibliotecaVista()
        +mostrarMenu()
        +mostrarLibros(List~Libro~ libros)
        +mostrarMensaje(String mensaje)
        +leerOpcion() int
        +leerTexto(String prompt) String
        +leerNumero(String prompt) int
        +solicitarDatosLibro() Libro
    }
    
    class BibliotecaSwingVista {
        -JTextField tituloField
        -JTextField autorField
        -JTextField cantidadField
        -JTextField busquedaField
        -JTable librosTable
        -DefaultTableModel tableModel
        -COLOR_FONDO_CLARO Color$
        -COLOR_PANEL Color$
        -COLOR_BOTON Color$
        -COLOR_TEXTO_OSCURO Color$
        -COLOR_BORDE Color$
        +BibliotecaSwingVista()
        -crearPanelFormulario() JPanel
        -crearPanelBusqueda() JPanel
        -crearPanelTabla() JPanel
        -crearEtiqueta(String texto) JLabel
        -crearCampoTexto(int columnas) JTextField
        -crearBoton(String texto, String actionCommand) JButton
        +setControladorListener(ActionListener listener)
        +getTitulo() String
        +getAutor() String
        +getCantidad() int
        +getTextoBusqueda() String
        +getIdSeleccionado() int
        +mostrarError(String mensaje)
        +mostrarExito(String mensaje)
        +limpiarCampos()
        +confirmarAccion(String mensaje) bool
    }
    
    %% Controlador
    class BibliotecaControlador {
        -IRepositorio~Libro~ repositorio
        -IVista vista
        +BibliotecaControlador(IRepositorio~Libro~ repo, IVista vista)
        +ejecutar()
        -procesarOpcion(int opcion)
        +agregarLibro()
        +listarLibros()
        +buscarLibro()
        +prestarLibro()
        +devolverLibro()
        +eliminarLibro()
        +getRepositorio() IRepositorio~Libro~
    }
    
    %% Aplicaciones
    class AplicacionMain {
        +main(String[] args)$
        -AplicacionMain()$
    }
    
    class Aplicacionweb {
        +main(String[] args)$
        -SwingControladorAdapter
    }
    
    class SwingControladorAdapter {
        -BibliotecaControlador controlador
        -BibliotecaSwingVista vista
        +SwingControladorAdapter(BibliotecaControlador controlador, BibliotecaSwingVista vista)
        +actionPerformed(ActionEvent e)
        -agregarLibro()
        -buscarPorTitulo()
        -buscarPorAutor()
        -buscarPorId()
        -prestarLibro()
        -devolverLibro()
        -eliminarLibro()
    }
    
    %% Relaciones de Herencia
    Libro --|> RecursoBiblioteca : extends
    BibliotecaRepositorio ..|> IRepositorio : implements
    BibliotecaControlador ..|> IControlador : implements
    BibliotecaVista ..|> IVista : implements
    BibliotecaSwingVista ..|> IVista : implements
    BibliotecaSwingVista --|> JFrame : extends
    SwingControladorAdapter ..|> ActionListener : implements
    
    %% Relaciones de Composición y Agregación
    BibliotecaControlador *-- IRepositorio : contains
    BibliotecaControlador *-- IVista : contains
    BibliotecaRepositorio *-- "many" Libro : manages
    SwingControladorAdapter *-- BibliotecaControlador : uses
    SwingControladorAdapter *-- BibliotecaSwingVista : uses
    Aplicacionweb *-- SwingControladorAdapter : inner class
    
    %% Relaciones de Dependencia
    AplicacionMain ..> BibliotecaRepositorio : creates
    AplicacionMain ..> BibliotecaVista : creates
    AplicacionMain ..> BibliotecaControlador : creates
    Aplicacionweb ..> BibliotecaRepositorio : creates
    Aplicacionweb ..> BibliotecaSwingVista : creates
    Aplicacionweb ..> BibliotecaControlador : creates
    
    %% Anotaciones para las clases principales
    note for IRepositorio "Interfaz genérica para\noperaciones CRUD"
    note for BibliotecaRepositorio "Implementación en memoria\ncon datos de prueba"
    note for Libro "Entidad principal del dominio\ncon lógica de negocio"
    note for BibliotecaControlador "Coordinador entre\nvista y repositorio"
    note for SwingControladorAdapter "Adaptador para eventos\nde la interfaz Swing"
```