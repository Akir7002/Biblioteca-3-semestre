package vista;

import modelo.Libro;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.List;

public class BibliotecaSwingVista extends JFrame implements IVista {

    private JTextField tituloField, autorField, cantidadField;
    private JTextField busquedaField;
    private JTable librosTable;
    private DefaultTableModel tableModel;

    // Paleta de colores cálida
    private static final Color COLOR_FONDO_CLARO = new Color(250, 245, 235); // Beige muy claro
    private static final Color COLOR_PANEL = new Color(245, 240, 230);      // Beige claro
    private static final Color COLOR_BOTON = new Color(179, 88, 54);        // Terracota
    private static final Color COLOR_TEXTO_OSCURO = new Color(51, 51, 51);  // Gris oscuro
    private static final Color COLOR_BORDE = new Color(211, 194, 174);      // Marrón claro

    public BibliotecaSwingVista() {
        setTitle("Biblioteca de Libros");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null); // Centrar la ventana
        getContentPane().setBackground(COLOR_FONDO_CLARO);

        // Crear componentes
        JLabel tituloPrincipal = new JLabel("Gestión de Biblioteca");
        tituloPrincipal.setFont(new Font("SansSerif", Font.BOLD, 28));
        tituloPrincipal.setForeground(COLOR_TEXTO_OSCURO);
        tituloPrincipal.setHorizontalAlignment(SwingConstants.CENTER);
        
        // Panel de Formulario
        JPanel formPanel = crearPanelFormulario();
        
        // Panel de Búsqueda y Acciones
        JPanel busquedaPanel = crearPanelBusqueda();
        
        // Panel de la Tabla
        JPanel tablaPanel = crearPanelTabla();

        // Contenedor principal
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout(15, 15));
        mainPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        mainPanel.setBackground(COLOR_FONDO_CLARO);

        mainPanel.add(tituloPrincipal, BorderLayout.NORTH);
        mainPanel.add(formPanel, BorderLayout.WEST);
        mainPanel.add(busquedaPanel, BorderLayout.CENTER);
        mainPanel.add(tablaPanel, BorderLayout.SOUTH);

        add(mainPanel);
    }

    private JPanel crearPanelFormulario() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(COLOR_BORDE, 1, true), "Registrar Libro"));
        panel.setBackground(COLOR_PANEL);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.anchor = GridBagConstraints.WEST;

        // Título
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(crearEtiqueta("Título:"), gbc);
        tituloField = crearCampoTexto(20);
        gbc.gridx = 1;
        panel.add(tituloField, gbc);

        // Autor
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(crearEtiqueta("Autor:"), gbc);
        autorField = crearCampoTexto(20);
        gbc.gridx = 1;
        panel.add(autorField, gbc);

        // Cantidad
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(crearEtiqueta("Cantidad:"), gbc);
        cantidadField = crearCampoTexto(5);
        gbc.gridx = 1;
        panel.add(cantidadField, gbc);

        // Botón
        JButton agregarBtn = crearBoton("Agregar Libro", "AGREGAR");
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.CENTER;
        panel.add(agregarBtn, gbc);

        return panel;
    }

    private JPanel crearPanelBusqueda() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(COLOR_BORDE, 1, true), "Buscar y Acciones"));
        panel.setBackground(COLOR_PANEL);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.anchor = GridBagConstraints.WEST;

        // Campo de búsqueda
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 3;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        panel.add(crearEtiqueta("Buscar por ID, Título o Autor:"), gbc);
        
        gbc.gridy = 1;
        busquedaField = crearCampoTexto(30);
        panel.add(busquedaField, gbc);

        // Botones de búsqueda
        gbc.gridwidth = 1;
        gbc.gridy = 2;
        gbc.fill = GridBagConstraints.NONE;
        
        gbc.gridx = 0;
        panel.add(crearBoton("Buscar por Título", "BUSCAR_TITULO"), gbc);
        
        gbc.gridx = 1;
        panel.add(crearBoton("Buscar por Autor", "BUSCAR_AUTOR"), gbc);
        
        gbc.gridx = 2;
        panel.add(crearBoton("Buscar por ID", "BUSCAR_ID"), gbc);
        
        // Botones de acción
        gbc.gridy = 3;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        panel.add(crearBoton("Prestar", "PRESTAR"), gbc);

        gbc.gridx = 1;
        panel.add(crearBoton("Devolver", "DEVOLVER"), gbc);
        
        gbc.gridx = 2;
        panel.add(crearBoton("Eliminar", "ELIMINAR"), gbc);
        
        // Botones de utilidad
        gbc.gridy = 4;
        gbc.gridx = 0;
        panel.add(crearBoton("Listar Todos", "LISTAR"), gbc);
        
        gbc.gridx = 1;
        panel.add(crearBoton("Limpiar Campos", "LIMPIAR"), gbc);

        return panel;
    }

    private JPanel crearPanelTabla() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(COLOR_FONDO_CLARO);

        tableModel = new DefaultTableModel(new Object[]{"ID", "Título", "Autor", "Disponibles"}, 0);
        librosTable = new JTable(tableModel);
        librosTable.setFillsViewportHeight(true);
        librosTable.setBackground(new Color(255, 255, 245));
        librosTable.setForeground(COLOR_TEXTO_OSCURO);
        librosTable.setSelectionBackground(COLOR_BORDE);
        librosTable.setSelectionForeground(Color.BLACK);
        librosTable.getTableHeader().setBackground(COLOR_BORDE);
        librosTable.getTableHeader().setForeground(COLOR_TEXTO_OSCURO);

        JScrollPane scrollPane = new JScrollPane(librosTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(COLOR_BORDE, 1, true));
        panel.add(scrollPane, BorderLayout.CENTER);
        
        // Añadir listener para seleccionar la fila
        librosTable.getSelectionModel().addListSelectionListener(event -> {
            if (!event.getValueIsAdjusting() && librosTable.getSelectedRow() != -1) {
                int selectedRow = librosTable.getSelectedRow();
                String id = tableModel.getValueAt(selectedRow, 0).toString();
                busquedaField.setText(id);
            }
        });
        
        return panel;
    }
    
    // Métodos utilitarios para crear componentes con el mismo estilo
    private JLabel crearEtiqueta(String texto) {
        JLabel label = new JLabel(texto);
        label.setForeground(COLOR_TEXTO_OSCURO);
        label.setFont(new Font("Arial", Font.PLAIN, 14));
        return label;
    }
    
    private JTextField crearCampoTexto(int columnas) {
        JTextField field = new JTextField(columnas);
        field.setBackground(Color.WHITE);
        field.setForeground(COLOR_TEXTO_OSCURO);
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(COLOR_BORDE, 1, true),
                new EmptyBorder(5, 8, 5, 8)
        ));
        return field;
    }
    
    private JButton crearBoton(String texto, String actionCommand) {
        JButton button = new JButton(texto);
        button.setBackground(COLOR_BOTON);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setActionCommand(actionCommand);
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(COLOR_BOTON, 1),
                new EmptyBorder(8, 15, 8, 15)
        ));
        return button;
    }

    // Métodos para interactuar con la vista
    public void setControladorListener(ActionListener listener) {
        // Enlazar los botones con el listener del controlador
        Component[] components = getContentPane().getComponents();
        for (Component c : components) {
            if (c instanceof JPanel) {
                for (Component sub : ((JPanel) c).getComponents()) {
                    if (sub instanceof JButton) {
                        ((JButton) sub).addActionListener(listener);
                    } else if (sub instanceof JPanel) {
                        for (Component subsub : ((JPanel) sub).getComponents()) {
                            if (subsub instanceof JButton) {
                                ((JButton) subsub).addActionListener(listener);
                            }
                        }
                    }
                }
            }
        }
    }

    public String getTitulo() {
        return tituloField.getText();
    }

    public String getAutor() {
        return autorField.getText();
    }

    public int getCantidad() {
        try {
            return Integer.parseInt(cantidadField.getText());
        } catch (NumberFormatException e) {
            return -1; // Valor para indicar error
        }
    }

    public String getTextoBusqueda() {
        return busquedaField.getText();
    }
    
    public int getIdSeleccionado() {
        try {
            return Integer.parseInt(busquedaField.getText());
        } catch (NumberFormatException e) {
            return -1; // Valor para indicar que no hay ID válido
        }
    }

    @Override
    public void mostrarLibros(List<Libro> libros) {
        tableModel.setRowCount(0); // Limpiar tabla
        for (Libro libro : libros) {
            tableModel.addRow(new Object[]{
                libro.getId(), 
                libro.getTitulo(), 
                libro.getAutor(), 
                libro.getCantidadDisponible()
            });
        }
    }

    @Override
    public void mostrarMensaje(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Información", JOptionPane.INFORMATION_MESSAGE);
    }

    public void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
    }
    
    public void mostrarExito(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Éxito", JOptionPane.INFORMATION_MESSAGE);
    }

    public void limpiarCampos() {
        tituloField.setText("");
        autorField.setText("");
        cantidadField.setText("");
        busquedaField.setText("");
    }
    
    public boolean confirmarAccion(String mensaje) {
        return JOptionPane.showConfirmDialog(this, mensaje, "Confirmar", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION;
    }
    
    // Implementación de métodos de IVista
    @Override
    public void mostrarMenu() {
        // En aplicación Swing, el menú es la propia interfaz gráfica
        setVisible(true);
    }
    
    @Override
    public int leerOpcion() {
        // En Swing, las opciones se manejan mediante eventos de botones
        return 0;
    }
    
    @Override
    public String leerTexto(String prompt) {
        return JOptionPane.showInputDialog(this, prompt);
    }
    
    @Override
    public int leerNumero(String prompt) {
        try {
            String input = JOptionPane.showInputDialog(this, prompt);
            return input != null ? Integer.parseInt(input) : -1;
        } catch (NumberFormatException e) {
            mostrarError("Debe ingresar un número válido.");
            return -1;
        }
    }
}