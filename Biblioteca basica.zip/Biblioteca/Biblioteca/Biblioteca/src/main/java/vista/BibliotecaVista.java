package vista;

import modelo.Libro;
import java.util.*;

public class BibliotecaVista implements IVista {
    private Scanner scanner;
    
    public BibliotecaVista() {
        this.scanner = new Scanner(System.in);
    }
    
    @Override
    public void mostrarMenu() {
        System.out.println("\n=== SISTEMA DE BIBLIOTECA ===");
        System.out.println("1. Agregar libro");
        System.out.println("2. Listar todos los libros");
        System.out.println("3. Buscar libro");
        System.out.println("4. Prestar libro");
        System.out.println("5. Devolver libro");
        System.out.println("6. Eliminar libro");
        System.out.println("0. Salir");
        System.out.print("Seleccione una opción: ");
    }
    
    @Override
    public void mostrarLibros(List<Libro> libros) {
        if (libros.isEmpty()) {
            System.out.println("No hay libros registrados.");
            return;
        }
        
        System.out.println("\n=== LISTA DE LIBROS ===");
        for (Libro libro : libros) {
            System.out.println(libro);
        }
    }
    
    @Override
    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }
    
    @Override
    public int leerOpcion() {
        try {
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar buffer después de leer el número
            return opcion;
        } catch (Exception e) {
            scanner.nextLine(); // Limpiar buffer
            return -1;
        }
    }
    
    @Override
    public String leerTexto(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine();
    }
    
    @Override
    public int leerNumero(String prompt) {
        System.out.print(prompt);
        try {
            int numero = scanner.nextInt();
            scanner.nextLine(); // Limpiar buffer después de leer el número
            return numero;
        } catch (Exception e) {
            scanner.nextLine(); // Limpiar buffer
            return -1;
        }
    }
    
    // Método específico
    public Libro solicitarDatosLibro() {
        String titulo;
        do {
            titulo = leerTexto("Ingrese el título: ");
            if (titulo.trim().isEmpty()) {
                System.out.println("El título no puede estar vacío. Intente nuevamente.");
            }
        } while (titulo.trim().isEmpty());
        
        String autor;
        do {
            autor = leerTexto("Ingrese el autor: ");
            if (autor.trim().isEmpty()) {
                System.out.println("El autor no puede estar vacío. Intente nuevamente.");
            }
        } while (autor.trim().isEmpty());
        
        int cantidad;
        do {
            cantidad = leerNumero("Ingrese la cantidad disponible: ");
            if (cantidad < 0) {
                System.out.println("La cantidad no puede ser negativa. Intente nuevamente.");
            }
        } while (cantidad < 0);
        
        return new Libro(titulo, autor, cantidad);
    }
}