package aplicacion;

import controlador.BibliotecaControlador;
import repositorio.BibliotecaRepositorio;
import vista.BibliotecaSwingVista;
import modelo.Libro;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class Aplicacionweb {

    public static void main(String[] args) {
        // Configurar el Look and Feel Nimbus para una apariencia más moderna y cálida
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception e) {
            System.err.println("No se pudo cargar el Look and Feel Nimbus. Se usará el L&F por defecto.");
        }

        // Ejecutar en el Event Dispatch Thread
        SwingUtilities.invokeLater(() -> {
            // Crear instancias
            BibliotecaRepositorio repositorio = new BibliotecaRepositorio();
            BibliotecaSwingVista vista = new BibliotecaSwingVista();
            BibliotecaControlador controlador = new BibliotecaControlador(repositorio, vista);

            // Crear el adaptador para manejar los eventos de la vista Swing
            SwingControladorAdapter adapter = new SwingControladorAdapter(controlador, vista);
            vista.setControladorListener(adapter);

            // Mostrar la ventana
            vista.setVisible(true);

            // Los libros se cargarán solo cuando el usuario haga clic en "Listar Todos"
        });
    }

    // Clase interna para adaptar los eventos de Swing al controlador
    private static class SwingControladorAdapter implements ActionListener {
        private BibliotecaControlador controlador;
        private BibliotecaSwingVista vista;

        public SwingControladorAdapter(BibliotecaControlador controlador, BibliotecaSwingVista vista) {
            this.controlador = controlador;
            this.vista = vista;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            String comando = e.getActionCommand();

            try {
                switch (comando) {
                    case "AGREGAR":
                        agregarLibro();
                        break;
                    case "LISTAR":
                        controlador.listarLibros();
                        break;
                    case "BUSCAR_TITULO":
                        buscarPorTitulo();
                        break;
                    case "BUSCAR_AUTOR":
                        buscarPorAutor();
                        break;
                    case "BUSCAR_ID":
                        buscarPorId();
                        break;
                    case "PRESTAR":
                        prestarLibro();
                        break;
                    case "DEVOLVER":
                        devolverLibro();
                        break;
                    case "ELIMINAR":
                        eliminarLibro();
                        break;
                    case "LIMPIAR":
                        vista.limpiarCampos();
                        break;
                    default:
                        vista.mostrarMensaje("Comando no reconocido: " + comando);
                }
            } catch (Exception ex) {
                vista.mostrarError("Error: " + ex.getMessage());
            }
        }

        private void agregarLibro() {
            String titulo = vista.getTitulo();
            String autor = vista.getAutor();
            int cantidad = vista.getCantidad();

            // Validaciones
            if (titulo.isEmpty()) {
                vista.mostrarError("El título no puede estar vacío.");
                return;
            }

            if (autor.isEmpty()) {
                vista.mostrarError("El autor no puede estar vacío.");
                return;
            }

            if (cantidad < 0) {
                vista.mostrarError("La cantidad no puede ser negativa.");
                return;
            }

            // Crear el libro
            Libro nuevoLibro = new Libro(titulo, autor, cantidad);

            // Usar el controlador para agregarlo
            if (controlador.getRepositorio().crear(nuevoLibro)) {
                vista.mostrarExito("Libro agregado exitosamente.");
                vista.limpiarCampos();
                controlador.listarLibros(); // Actualizar la lista
            } else {
                vista.mostrarError("Error al agregar el libro.");
            }
        }

        private void buscarPorTitulo() {
            String titulo = vista.getTextoBusqueda();
            if (titulo.isEmpty()) {
                vista.mostrarError("Ingrese un título para buscar.");
                return;
            }

            BibliotecaRepositorio repo = (BibliotecaRepositorio) controlador.getRepositorio();
            List<Libro> resultados = repo.buscarPorTitulo(titulo);

            if (resultados.isEmpty()) {
                vista.mostrarMensaje("No se encontraron libros con el título: " + titulo);
            } else {
                vista.mostrarLibros(resultados);
                vista.mostrarMensaje("Se encontraron " + resultados.size() + " libro(s) con el título: " + titulo);
            }
        }

        private void buscarPorAutor() {
            String autor = vista.getTextoBusqueda();
            if (autor.isEmpty()) {
                vista.mostrarError("Ingrese un autor para buscar.");
                return;
            }

            BibliotecaRepositorio repo = (BibliotecaRepositorio) controlador.getRepositorio();
            List<Libro> resultados = repo.buscarPorAutor(autor);

            if (resultados.isEmpty()) {
                vista.mostrarMensaje("No se encontraron libros del autor: " + autor);
            } else {
                vista.mostrarLibros(resultados);
                vista.mostrarMensaje("Se encontraron " + resultados.size() + " libro(s) del autor: " + autor);
            }
        }

        private void buscarPorId() {
            String idTexto = vista.getTextoBusqueda();
            if (idTexto.isEmpty()) {
                vista.mostrarError("Ingrese un ID para buscar.");
                return;
            }

            try {
                int id = Integer.parseInt(idTexto);
                Libro libro = controlador.getRepositorio().obtenerPorId(id);

                if (libro != null) {
                    List<Libro> resultado = List.of(libro);
                    vista.mostrarLibros(resultado);
                    vista.mostrarMensaje("Libro encontrado con ID: " + id);
                } else {
                    vista.mostrarMensaje("No se encontró libro con ID: " + id);
                }
            } catch (NumberFormatException e) {
                vista.mostrarError("El ID debe ser un número válido.");
            }
        }

        private void prestarLibro() {
            int id = vista.getIdSeleccionado();
            if (id == -1) {
                vista.mostrarError("Seleccione un libro de la tabla o ingrese un ID en el campo.");
                return;
            }

            if (vista.confirmarAccion("¿Está seguro de que desea prestar el libro con ID " + id + "?")) {
                BibliotecaRepositorio repo = (BibliotecaRepositorio) controlador.getRepositorio();
                if (repo.prestar(id)) {
                    vista.mostrarExito("Libro prestado exitosamente.");
                    controlador.listarLibros();
                } else {
                    vista.mostrarError("No se pudo prestar el libro. Verifique si está disponible.");
                }
            }
        }

        private void devolverLibro() {
            int id = vista.getIdSeleccionado();
            if (id == -1) {
                vista.mostrarError("Seleccione un libro de la tabla o ingrese un ID en el campo.");
                return;
            }

            if (vista.confirmarAccion("¿Está seguro de que desea devolver el libro con ID " + id + "?")) {
                BibliotecaRepositorio repo = (BibliotecaRepositorio) controlador.getRepositorio();
                if (repo.devolver(id)) {
                    vista.mostrarExito("Libro devuelto exitosamente.");
                    controlador.listarLibros();
                } else {
                    vista.mostrarError("No se pudo devolver el libro. Verifique si ya está en la biblioteca.");
                }
            }
        }

        private void eliminarLibro() {
            int id = vista.getIdSeleccionado();
            if (id == -1) {
                vista.mostrarError("Seleccione un libro de la tabla o ingrese un ID en el campo.");
                return;
            }

            if (vista.confirmarAccion("¿Está seguro de que desea eliminar el libro con ID " + id + "? Esta acción no se puede deshacer.")) {
                if (controlador.getRepositorio().eliminar(id)) {
                    vista.mostrarExito("Libro eliminado exitosamente.");
                    vista.limpiarCampos();
                    controlador.listarLibros(); // Actualizar la lista
                } else {
                    vista.mostrarError("Error al eliminar el libro. Verifique que el ID sea correcto.");
                }
            }
        }
    }
}