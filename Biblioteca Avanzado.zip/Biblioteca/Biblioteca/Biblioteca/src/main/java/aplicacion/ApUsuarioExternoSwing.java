package aplicacion;

import modelo.Libro;
import repositorio.BibliotecaRepositorio;
import repositorio.IRepositorio;
import vista.VistaUsuarioExternoSwing;
import controlador.ControladorUsuarioExternoSwing;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

public class ApUsuarioExternoSwing {
    
    public static void main(String[] args) {
        // Configurar el Look and Feel del sistema operativo
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (ClassNotFoundException | InstantiationException | 
                 IllegalAccessException | UnsupportedLookAndFeelException e) {
            System.err.println("No se pudo configurar el Look and Feel: " + e.getMessage());
            // Continuar con el Look and Feel por defecto
        }
        
        // Ejecutar la aplicación en el Event Dispatch Thread
        SwingUtilities.invokeLater(() -> {
            try {
                iniciarCatalogoPublico();
            } catch (Exception e) {
                System.err.println("Error al iniciar el catálogo público: " + e.getMessage());
                e.printStackTrace();
            }
        });
    }
    
    private static void iniciarCatalogoPublico() {
        System.out.println("Iniciando Catálogo Público de la Biblioteca...");
        
        // Crear repositorio (solo lectura)
        IRepositorio<Libro> repositorioLibros = new BibliotecaRepositorio();
        
        // Crear vista específica para usuarios externos
        VistaUsuarioExternoSwing vista = new VistaUsuarioExternoSwing();
        
        // Crear controlador específico
        ControladorUsuarioExternoSwing controlador = new ControladorUsuarioExternoSwing(
                repositorioLibros, vista);
        
        // Cargar datos de ejemplo
        cargarDatosEjemplo(repositorioLibros);
        
        // Ejecutar aplicación pública
        controlador.ejecutar();
        
        System.out.println("Catálogo Público iniciado correctamente.");
    }
    
    private static void cargarDatosEjemplo(IRepositorio<Libro> repositorio) {
        // Libros de ejemplo para consulta pública
        repositorio.crear(new Libro("Don Quijote de la Mancha", "Miguel de Cervantes", 3));
        repositorio.crear(new Libro("Cien Años de Soledad", "Gabriel García Márquez", 2));
        repositorio.crear(new Libro("1984", "George Orwell", 4));
        repositorio.crear(new Libro("El Principito", "Antoine de Saint-Exupéry", 0)); // Agotado
        repositorio.crear(new Libro("Orgullo y Prejuicio", "Jane Austen", 3));
        repositorio.crear(new Libro("Crimen y Castigo", "Fiódor Dostoyevski", 1));
        repositorio.crear(new Libro("La Odisea", "Homero", 2));
        repositorio.crear(new Libro("Hamlet", "William Shakespeare", 0)); // Agotado
        repositorio.crear(new Libro("El Gran Gatsby", "F. Scott Fitzgerald", 2));
        repositorio.crear(new Libro("Rayuela", "Julio Cortázar", 1));
        repositorio.crear(new Libro("El señor de los anillos", "J.R.R. Tolkien", 3));
        repositorio.crear(new Libro("Harry Potter y la piedra filosofal", "J.K. Rowling", 4));
        repositorio.crear(new Libro("El código Da Vinci", "Dan Brown", 2));
        repositorio.crear(new Libro("Los miserables", "Victor Hugo", 1));
        repositorio.crear(new Libro("El alquimista", "Paulo Coelho", 5));
        repositorio.crear(new Libro("Crónica de una muerte anunciada", "Gabriel García Márquez", 2));
        repositorio.crear(new Libro("La casa de los espíritus", "Isabel Allende", 1));
        repositorio.crear(new Libro("El perfume", "Patrick Süskind", 3));
        repositorio.crear(new Libro("Beloved", "Toni Morrison", 1));
        repositorio.crear(new Libro("El nombre de la rosa", "Umberto Eco", 2));
        
        System.out.println("Catálogo público cargado:");
        System.out.println("- 20 títulos disponibles para consulta");
        System.out.println("- Algunos libros con disponibilidad limitada");
        System.out.println("- 2 títulos temporalmente agotados");
    }
}